package com.example.pokemon;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recycler);

        ArrayList<Pokemon> pokemonArrayList = new ArrayList<>();

        Pokemon poke1 = new Pokemon("Snorlax", R.drawable.snorlax,50,150,200);
        Pokemon poke2 = new Pokemon("Greninja", R.drawable.greninja,200,200,400);
        Pokemon poke3 = new Pokemon("Charizard", R.drawable.charizardmegax,200,150,350);
        Pokemon poke4 = new Pokemon("Rotom", R.drawable.rotom,15,50,65);
        Pokemon poke5 = new Pokemon("Pikachu", R.drawable.pikachu,150,150,300);

        pokemonArrayList.add(poke1);
        pokemonArrayList.add(poke2);
        pokemonArrayList.add(poke3);
        pokemonArrayList.add(poke4);
        pokemonArrayList.add(poke5);

        RecyclerView rv = findViewById(R.id.recycler);

        rv.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        rv.setLayoutManager(lm);

        PokemonAdapter pa = new PokemonAdapter(pokemonArrayList, this);
        rv.setAdapter(pa);

    }
}