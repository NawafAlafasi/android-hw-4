package com.example.pokemon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Details extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        ImageView img = findViewById(R.id.imageView2);
        TextView name = findViewById(R.id.name);
        TextView attack = findViewById(R.id.attack);
        TextView defence = findViewById(R.id.defence);

        Bundle poke = getIntent().getExtras();
        Pokemon pokemon = (Pokemon) poke.getSerializable("pokeball");

        img.setImageResource(pokemon.getImage());
        name.setText(pokemon.getName());
        attack.setText("Attack: "+ pokemon.getAttack()+"");
        defence.setText("Defence: "+pokemon.getDefence()+"");

    }
}